﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WcfServiceTest
{
    [DataContract]
    public class UserObject
    {
        String username, password;
        public UserObject()
        {

        }
        
        
        [DataMember]
        public String Username
        {  
            get { return username; }
            set { username = value; }
        }
        [DataMember]
        public String Password
        {
            get { return password; }
            set { password = value; }
        }

    }
}