﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WcfServiceTest
{
    [DataContract]
    public class SongObject
    {
        string s_id, title, duration, path, a_id, playstatus,singer,albumName, periority;
        [DataMember]
        public string AlbumName
        {
            get { return albumName; }
            set { albumName = value; }
        }
        [DataMember]
        public string Singer
        {
            get { return singer; }
            set { singer = value; }
        }
        [DataMember]
        public string Playstatus
        {
            get { return playstatus; }
            set { playstatus = value; }
        }
        [DataMember]
        public string A_id
        {
            get { return a_id; }
            set { a_id = value; }
        }
        [DataMember]
        public string Path
        {
            get { return path; }
            set { path = value; }
        }
        [DataMember]
        public string Duration
        {
            get { return duration; }
            set { duration = value; }
        }
        [DataMember]
        public string Title
        {
            get { return title; }
            set { title = value; }
        }
        [DataMember]
        public string S_id
        {
            get { return s_id; }
            set { s_id = value; }
        }
        [DataMember]
        public string Periority
        {
            get { return periority; }
            set { periority = value; }
        }

    }




}