﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WcfServiceTest
{
    [DataContract]
    public class TokenObject
    {

        String t_id
        , purchasedby
        , purchasedate
        , tokentitle_id
        , tokenstatus
        , tcount
        , imei
        , tableNumber;
      
        

        public TokenObject()
        {

        }
        [DataMember]
        public String TableNumber
        {
            get { return tableNumber; }
            set { tableNumber = value; }
        }
        [DataMember]
        public String Imei
        {
            get { return imei; }
            set { imei = value; }
        }
        [DataMember]
        public String Tcount
        {
            get { return tcount; }
            set { tcount = value; }
        }
        [DataMember]
        public String Tokenstatus
        {
            get { return tokenstatus; }
            set { tokenstatus = value; }
        }
        [DataMember]
        public String Tokentitle_id
        {
            get { return tokentitle_id; }
            set { tokentitle_id = value; }
        }
        [DataMember]
        public String Purchasedate
        {
            get { return purchasedate; }
            set { purchasedate = value; }
        }
        [DataMember]
        public String Purchasedby
        {
            get { return purchasedby; }
            set { purchasedby = value; }
        }
        [DataMember]
        public String T_id
        {
            get { return t_id; }
            set { t_id = value; }
        }
        [DataMember]
        public List<TokenHistory> History { get; set; }
        [DataMember]
        public Restaurant RestaurantInfo { get; set; }
    }
}