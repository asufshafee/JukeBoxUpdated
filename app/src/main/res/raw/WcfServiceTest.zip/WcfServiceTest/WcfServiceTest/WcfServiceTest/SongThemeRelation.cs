﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WcfServiceTest
{
  [DataContract]
    public class SongThemeRelation
    {
      string s_id
      , theme_id;
        [DataMember]
      public string Theme_id
      {
          get { return theme_id; }
          set { theme_id = value; }
      }
      [DataMember]
      public string S_id
      {
          get { return s_id; }
          set { s_id = value; }
      }





    }
}