﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WcfServiceTest
{
    public class Restaurant
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string City { get; set; }

        public static Restaurant GetRestaurant(string id)
        {
            Restaurant restaurant = null;

            using (var con = new SqlConnection(Operations.QueryString))
            {
                using (var cmd = new SqlCommand("select * from tblRestaurants where rid = @id", con))
                {
                    con.Open(); 
                    cmd.Parameters.AddWithValue("@id", id);

                    var sdr = cmd.ExecuteReader();

                    while (sdr.Read())
                    {
                        restaurant = new Restaurant
                        {
                            Id = sdr["rid"].ToString(),
                            Name = sdr["Name"].ToString(),
                            City = sdr["City"].ToString()
                        };
                    }

                    con.Close();
                }
            }

            return restaurant;

        }

        public static List<Restaurant> GetAll()
        {
            var list = new List<Restaurant>();
            using (var con = new SqlConnection(Operations.QueryString))
            {
                using (var cmd = new SqlCommand("select * from tblRestaurants", con))
                {
                    con.Open();

                    var sdr = cmd.ExecuteReader();

                    while (sdr.Read())
                    {
                        list.Add(new Restaurant
                        {
                            Id = sdr["rid"].ToString(),
                            Name = sdr["Name"].ToString(),
                            City = sdr["City"].ToString()
                        });
                    }

                    con.Close();
                }
            }
            return list;
        }
    }
}