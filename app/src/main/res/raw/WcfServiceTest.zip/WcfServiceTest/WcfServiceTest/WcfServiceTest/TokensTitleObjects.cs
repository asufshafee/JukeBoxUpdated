﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WcfServiceTest
{
    [DataContract]
    public class TokensTitleObjects
    {
        string title_id
      , title;

        public string Title
        {
            get { return title; }
            set { title = value; }
        }
        [DataMember]
        public string Title_id
        {
            get { return title_id; }
            set { title_id = value; }
        }



    }
}