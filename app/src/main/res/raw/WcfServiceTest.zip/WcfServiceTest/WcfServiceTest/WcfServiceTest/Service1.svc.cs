﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfServiceTest
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        DatabaseOperation db = new DatabaseOperation();



        public List<AlbumObject> slectAlbum()
        {
            List<AlbumObject> list = new List<AlbumObject>();
            DataTable dt = new DataTable();
            String q = "Select * from tblAlbum";
            dt = db.getDataFromDB(q);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                AlbumObject obj = new AlbumObject();
                obj.A_id = dt.Rows[i][0].ToString();
                obj.Name = dt.Rows[i][1].ToString();
                obj.Artist = dt.Rows[i][2].ToString();
                obj.Year = dt.Rows[i][3].ToString();
                list.Add(obj);
            }
            return list;
        }


        public string insertDedications(string dedicatedBy, string dedicatedTo, string dedicationType, string q_id, string dedicationmessage, string deviceId, string NoOfTokens, string rid, string tokenType)
        {
            string q;

            int TotalTokens = 0;
            Dictionary<string, int> tokens = new Dictionary<string, int>();
            DataTable datatable = new DataTable();
            String query = "Select * from tblTokens where imei='" + deviceId + "' and tokentitle_id='"+tokenType+"'";
            datatable = db.getDataFromDB(query);
            for (int k = 0; k < datatable.Rows.Count; k++)
            {
                if (datatable.Rows[k][4].ToString().Equals("1"))
                {
                    tokens.Add(datatable.Rows[k][0].ToString(), Convert.ToInt32(datatable.Rows[k][5]));
                    TotalTokens +=  Convert.ToInt32(datatable.Rows[k][5]);
                }

            }

          
            int Left = 0;
            var requestedTotalTokens = Convert.ToInt32(NoOfTokens);
            if(requestedTotalTokens < 1)
            {
                return "Request cannot be processed due to incorrect token specification";
            }
            if(requestedTotalTokens > TotalTokens)
            {
                return "Insufficient tokens to process this request!";
            }

            
            foreach (var token in tokens)
	        {
		        // TotalTokens = TotalTokens + token.Value;
                if(requestedTotalTokens == 0)break;
                if(requestedTotalTokens <= token.Value)
                {
                    string tokenQuery  = "update tblTokens set tcount ='"+(token.Value - requestedTotalTokens)+"' where t_id = '"+token.Key+"' and imei='" + deviceId + "'";
                    db.InsertDataQuery(tokenQuery);

                    tokenQuery = "insert into tblTokenHistory values('" + token.Key + "', '" + requestedTotalTokens + "')";
                    db.InsertDataQuery(tokenQuery);
                    requestedTotalTokens = 0;
                    break;
                }
                else if(token.Value > 0)
                {
                    

                    requestedTotalTokens -= token.Value;

                    string tokenQuery  = "update tblTokens set tcount ='0' where t_id = '"+token.Key+"' and imei='" + deviceId + "'";
                    db.InsertDataQuery(tokenQuery);

                    tokenQuery = "insert into tblTokenHistory values('" + token.Key + "', '" + token.Value + "')";
                    db.InsertDataQuery(tokenQuery);

                }

                
	        }


            String query2 = ""; // "update  tblTokens set tcount='" + Left.ToString() + "' where imei='" + deviceId + "'";
            if (requestedTotalTokens < 1 /*db.InsertDataQuery(query2)*/)
            {
                int Periority = int.Parse(NoOfTokens) * Convert.ToInt32(tokenType);

                DataTable datatable1 = new DataTable();
                String query1 = "Select * from tblQueue where s_id='" + q_id + "' and rid = " + rid;
                datatable1 = db.getDataFromDB(query1);
                if (datatable1.Rows.Count > 0)
                {
                    Periority = Periority + int.Parse(datatable1.Rows[0][2].ToString());
                    q = "update  tblQueue set Spriority='" + Periority + "' where q_id='" + datatable1.Rows[0][0].ToString() + "' and rid = " + rid;
                    if (db.InsertDataQuery(q))
                    {

                        q = "insert into tblDedications values('" + Operations.GetId("tblDedications") + "','" + dedicatedBy + "','" + dedicatedTo + "','" + dedicationType + "','" + datatable1.Rows[0][0].ToString() + "','" + dedicationmessage + "','" + deviceId + "', '" + rid + "')";
                        if (db.InsertDataQuery(q))
                        {
                            AddHistory(q_id, NoOfTokens);
                            return "Dedications Success";
                        }
                        else
                        {
                            return "Dedications Not Success";
                        }
                       
                    }
                    else
                    {
                        return "Request Not Completed";
                    }
                }
                else
                {
                    var qid = Operations.GetId("tblQueue");
                    q = "insert into tblQueue values('" + qid + "','" + q_id + "','" + Periority.ToString() + "', '" + rid + "')";
                    if (db.InsertDataQuery(q))
                    {
                        q = "insert into tblDedications values('" + Operations.GetId("tblDedications") + "','" + dedicatedBy + "','" + dedicatedTo + "','" + dedicationType + "','" + qid + "','" + dedicationmessage + "','" + deviceId + "', '" + rid + "')";
                        if (db.InsertDataQuery(q))
                        {
                            AddHistory(q_id, NoOfTokens);
                            return "Dedications Success";
                        }
                        else
                        {
                            return "Dedications Not Success";
                        }
                    }
                    else
                    {
                        return "Request Not Completed";
                    }
                }

            }
           
            else
            {
                return "Request Not Completed";
            }


        }










        public List<ThemeObject> selecTheme(string rid)
        {
            List<ThemeObject> list = new List<ThemeObject>();
            DataTable dt = new DataTable();
            String q = "Select * from tblTheme where rid = " + rid;
            dt = db.getDataFromDB(q);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i][2].ToString().Equals("ACTIVE", StringComparison.OrdinalIgnoreCase))
                {
                    ThemeObject obj = new ThemeObject();
                    obj.Theme_id = dt.Rows[i][0].ToString();
                    obj.Name = dt.Rows[i][1].ToString();
                    obj.Status = dt.Rows[i][2].ToString();

                    list.Add(obj);
                }

            }
            return list;
        }






        public List<QueueObject> selectQueueObject(string rid)
        {
            List<QueueObject> list = new List<QueueObject>();
            DataTable dt = new DataTable();
            String q = "Select * from tblQueue where rid = " + rid;
            dt = db.getDataFromDB(q);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                QueueObject obj = new QueueObject();
                obj.Q_id = dt.Rows[i][0].ToString();
                obj.S_id = dt.Rows[i][1].ToString();
                obj.Priority = dt.Rows[i][2].ToString();

                list.Add(obj);
            }
            return list;
        }

        public List<SongObject> GetQueue(string rid)
        {

            List<QueueObject> queue = selectQueueObject(rid);
            List<SongObject> list = new List<SongObject>();
            DataTable dt = new DataTable();
            String q = "Select * from tblSongs";
            dt = db.getDataFromDB(q);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                SongObject obj = new SongObject();
                DataTable datatable = new DataTable();
                String query = "Select * from tblAlbum where name='" + dt.Rows[i][4].ToString() + "' and rid = " + rid;
                datatable = db.getDataFromDB(query);
                for (int k = 0; k < datatable.Rows.Count; k++)
                {
                    obj.Singer = datatable.Rows[k][2].ToString();
                    obj.AlbumName = datatable.Rows[k][1].ToString();
                    obj.Duration = dt.Rows[i][2].ToString();
                    obj.Title = dt.Rows[i][1].ToString();
                    obj.A_id = dt.Rows[i][4].ToString();
                    obj.S_id = dt.Rows[i][0].ToString();
                }


                for (int j = 0; j < queue.Count; j++)
                {
                    if (queue[j].S_id.Equals(dt.Rows[i][0].ToString()))
                    {
                        obj.Periority = queue[j].Priority;
                        list.Add(obj);
                    }

                }

            }
            return list;

        }


        public List<SongObject> GetLibrary(string Album, string rid)
        {
            /**   List<SongObject> list = new List<SongObject>();
         
               DataTable datatable = new DataTable();
               String query = "Select * from tblAlbum where name='" + Album + "'";
               datatable = db.getDataFromDB(query);
               for (int k = 0; k < datatable.Rows.Count; k++)
               {
               
               
              
                   DataTable dt = new DataTable();
                   String q = "Select * from tblSongs where a_id='" + datatable.Rows[k][1].ToString() + "'";
                   dt = db.getDataFromDB(q);
                   for (int i = 0; i < dt.Rows.Count; i++)
                   {
                       SongObject obj = new SongObject();
                       obj.Singer = datatable.Rows[k][2].ToString();
                       obj.AlbumName = datatable.Rows[k][1].ToString();
                       obj.Duration = dt.Rows[i][2].ToString();
                       obj.Title = dt.Rows[i][1].ToString();
                       obj.A_id = dt.Rows[i][4].ToString();
                       obj.S_id = dt.Rows[i][0].ToString();
                       list.Add(obj);

                   }
               

               }


               return list;**/





            List<SongObject> list = new List<SongObject>();
            DataTable dt = new DataTable();
            String q = "Select * from tblSongs where rid = " + rid;
            
            dt = db.getDataFromDB(q);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string relationShip = "select * from tblSongThemeRelation r join tblTheme t on r.theme_id = t.theme_id where t.status = 'Active' and r.s_id = '" + dt.Rows[i][0].ToString() + "' and t.rid = " + rid;



                var dtRelation = db.getDataFromDB(relationShip);

                if (dtRelation.Rows.Count < 1) continue;


                SongObject obj = new SongObject();
                String query = "Select * from tblAlbum where name='" + dt.Rows[i][4].ToString() + "' and rid = " + rid;

                DataTable datatable = new DataTable();
                datatable = db.getDataFromDB(query);

                if (datatable.Rows.Count > 0)
                {
                    obj.Singer = datatable.Rows[0][2].ToString();
                    obj.AlbumName = datatable.Rows[0][1].ToString();
                }
                else
                {
                    obj.Singer = "UnKnown";
                    obj.AlbumName = "UnKnown";
                }


                obj.Duration = dt.Rows[i][2].ToString();
                obj.Title = dt.Rows[i][1].ToString();
                obj.A_id = dt.Rows[i][4].ToString();
                obj.S_id = dt.Rows[i][0].ToString();

                obj.Playstatus = dt.Rows[i][5].ToString();
                list.Add(obj);

            }





            return list;



        }

        private void AddHistory(string songId, string priority)
        {
            if (HistoryExists(songId))
            {
                using (var con = new SqlConnection(Operations.QueryString))
                {
                    using (var cmd = new SqlCommand("update History set counter = counter + @prio where song_id=@sid", con))
                    {
                        cmd.Parameters.AddWithValue("@sid", songId);
                        cmd.Parameters.AddWithValue("@prio", priority);
                        con.Open();

                        cmd.ExecuteNonQuery();

                        con.Close();
                    }
                }
            }
            else
            {
                using (var con = new SqlConnection(Operations.QueryString))
                {
                    using (var cmd = new SqlCommand("insert into History values(@sid, @prio)", con))
                    {
                        cmd.Parameters.AddWithValue("@sid", songId);
                        cmd.Parameters.AddWithValue("@prio", priority);
                        con.Open();

                        cmd.ExecuteNonQuery();

                        con.Close();
                    }
                }
            }
        }

        private bool HistoryExists(string songId)
        {
            bool exists;

            using (var con = new SqlConnection(Operations.QueryString))
            {
                using (var cmd = new SqlCommand("select * from History where song_id = @sid", con))
                {
                    cmd.Parameters.AddWithValue("@sid", songId);

                    con.Open();

                    exists = cmd.ExecuteReader().HasRows;

                    con.Close();
                }
            }
            return exists;
        }
        public List<SongObject> GetAllPoopularSongs(string r_id)
        {
            List<SongObject> list = new List<SongObject>();

            String query1 = "Select * from History  order by counter desc;";
            DataTable dataTable = new DataTable();
            dataTable = db.getDataFromDB(query1);
            for (int j = 0; j < dataTable.Rows.Count; j++)
            {
                DataTable dt = new DataTable();
                String q = "Select * from tblSongs where s_id='" + dataTable.Rows[j][0].ToString() + "' and rid=" + r_id;
                dt = db.getDataFromDB(q);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SongObject obj = new SongObject();
                    String query = "Select * from tblAlbum where name='" + dt.Rows[i][4].ToString() + "' and rid=" + r_id;

                    DataTable datatable = new DataTable();
                    datatable = db.getDataFromDB(query);

                    if (datatable.Rows.Count > 0)
                    {
                        obj.Singer = datatable.Rows[0][2].ToString();
                        obj.AlbumName = datatable.Rows[0][1].ToString();
                    }
                    else
                    {
                        obj.Singer = "UnKnown";
                        obj.AlbumName = "UnKnown";
                    }


                    obj.Duration = dt.Rows[i][2].ToString();
                    obj.Title = dt.Rows[i][1].ToString();
                    obj.A_id = dt.Rows[i][4].ToString();
                    obj.S_id = dt.Rows[i][0].ToString();
                    obj.Playstatus = dt.Rows[i][5].ToString();
                    list.Add(obj);

                }



            }






            return list;
        }



        public String GetTokens(String Username, String TableNumber, String NoofTokens, String deviceID, string rid, string tokenType)
        {
            // string q= "select t_id from tblTokens oder by t_id desc' ";
            DateTime dateTime = DateTime.UtcNow.Date;

            //if (!TokenRowExists(deviceID))
            //{
            //    GetCurrentTokens(did);
            //    using (var con = new SqlConnection(Operations.QueryString))
            //    {
            //        using (var cmd = new SqlCommand("update tblTokens tcount = tcount + @tokens where imei = @did", con))
            //        {

            //        }
            //    }
            //}

            string q = "insert into tblTokens values('" + Operations.GetId("tblTokens") + "','" + Username + "','" + dateTime.ToString("dd/MM/yyyy") + "','" + tokenType + "','0','" + NoofTokens + "','" + deviceID + "','" + TableNumber + "', '" + rid + "')";
            if (db.InsertDataQuery(q))
            {
                return "Request Submited";
            }
            else
            {
                return "Request Not Submited";
            }


        }

        public int GetCurrentTokens(string deviceId)
        {
            int tokens = 0;

            using (var con = new SqlConnection(Operations.QueryString))
            {
                using (var cmd = new SqlCommand("select * from tblTokens where imei=@did", con))
                {
                    cmd.Parameters.AddWithValue("@did", deviceId);

                    con.Open();

                    var sdr = cmd.ExecuteReader();

                    if (sdr.Read())
                    {

                    }

                    con.Close();
                }
            }
            return tokens;

        }
        public bool TokenRowExists(string deviceId)
        {
            bool exists;
            using (var con = new SqlConnection(Operations.QueryString))
            {
                using (var cmd = new SqlCommand("select * from tblTokens where imei = @did", con))
                {
                    cmd.Parameters.AddWithValue("@did", deviceId);

                    con.Open();
                    exists = cmd.ExecuteReader().HasRows;

                    con.Close();
                }
            }
            return exists;
        }

        public List<TokenObject> GetRequests(String deviceID)
        {

            List<TokenObject> list = new List<TokenObject>();

            DataTable datatable = new DataTable();
            String query = "Select * from tblTokens where imei='" + deviceID + "'";
            datatable = db.getDataFromDB(query);
            for (int k = 0; k < datatable.Rows.Count; k++)
            {
                TokenObject obj = new TokenObject();
                obj.T_id = datatable.Rows[k][0].ToString();
                obj.Purchasedby = datatable.Rows[k][1].ToString();
                obj.Purchasedate = datatable.Rows[k][2].ToString();
                obj.Tokentitle_id = datatable.Rows[k][3].ToString();
                obj.Tokenstatus = datatable.Rows[k][4].ToString();
                obj.Tcount = datatable.Rows[k][5].ToString();
                obj.Imei = datatable.Rows[k][6].ToString();
                obj.RestaurantInfo = Restaurant.GetRestaurant(datatable.Rows[k]["rid"].ToString());
                obj.TableNumber = datatable.Rows[k][7].ToString();
                obj.History = TokenHistory.GetHistory(datatable.Rows[k]["t_id"].ToString());
                list.Add(obj);
            }


            return list;

        }

        public string RequestSong(String deviceID, string NoOFTokens, string song_id, string rid, string tokenType)
        {
            var NoOFTokens1 = NoOFTokens;
            int TotalTokens = 0;
            Dictionary<string, int> tokens = new Dictionary<string, int>();
            DataTable datatable = new DataTable();
            String query = "Select * from tblTokens where imei='" + deviceID + "' and tokentitle_id = '" + tokenType + "'";
            datatable = db.getDataFromDB(query);
            for (int k = 0; k < datatable.Rows.Count; k++)
            {
                if (datatable.Rows[k][4].ToString().Equals("1"))
                {
                    tokens.Add(datatable.Rows[k][0].ToString(), Convert.ToInt32(datatable.Rows[k][5]));
                    TotalTokens += Convert.ToInt32(datatable.Rows[k][5]);
                }

            }


            int Left = 0;
            var requestedTotalTokens = Convert.ToInt32(NoOFTokens);
            if (requestedTotalTokens < 1)
            {
                return "Request cannot be processed due to incorrect token specification";
            }
            if (requestedTotalTokens > TotalTokens)
            {
                return "Insufficient tokens to process this request!";
            }


            foreach (var token in tokens)
            {
                // TotalTokens = TotalTokens + token.Value;
                if (requestedTotalTokens == 0) break;
                if (requestedTotalTokens <= token.Value)
                {
                    string tokenQuery = "update tblTokens set tcount ='" + (token.Value - requestedTotalTokens) + "' where t_id = '" + token.Key + "' and imei='" + deviceID + "'";
                    db.InsertDataQuery(tokenQuery);

                    tokenQuery = "insert into tblTokenHistory values('" + token.Key + "', '" + requestedTotalTokens + "')";
                    db.InsertDataQuery(tokenQuery);
                    requestedTotalTokens = 0;
                    break;
                }
                else if (token.Value > 0)
                {


                    requestedTotalTokens -= token.Value;

                    string tokenQuery = "update tblTokens set tcount ='0' where t_id = '" + token.Key + "' and imei='" + deviceID + "'";
                    db.InsertDataQuery(tokenQuery);

                    tokenQuery = "insert into tblTokenHistory values('" + token.Key + "', '" + token.Value + "')";
                    db.InsertDataQuery(tokenQuery);

                }


            }

            // String query2 = "update  tblTokens set tcount='" + Left.ToString() + "' where imei='" + deviceID + "'";
            if (requestedTotalTokens < 1 /*db.InsertDataQuery(query2)*/ )
            {
                int Periority = int.Parse(NoOFTokens1) * Convert.ToInt32(tokenType);

                DataTable datatable1 = new DataTable();
                String query1 = "Select * from tblQueue where s_id='" + song_id + "' and rid = " + rid;
                datatable1 = db.getDataFromDB(query1);
                if (datatable1.Rows.Count > 0)
                {
                    Periority = Periority + int.Parse(datatable1.Rows[0][2].ToString());
                    string q = "update  tblQueue set Spriority='" + Periority + "' where q_id='" + datatable1.Rows[0][0].ToString() + "' and rid = " + rid;
                    if (db.InsertDataQuery(q))
                    {
                        AddHistory(song_id, NoOFTokens1);
                        return "Request Success";
                    }
                    else
                    {
                        return "Request Not Completed";
                    }
                }
                else
                {
                    string q = "insert into tblQueue values('" + Operations.GetId("tblQueue") + "','" + song_id + "','" + Periority.ToString() + "', '" + rid + "')";
                    if (db.InsertDataQuery(q))
                    {
                        AddHistory(song_id, NoOFTokens1);
                        return "Request Success";
                    }
                    else
                    {
                        return "Request Not Completed";
                    }
                }


            }
            else
            {
                return "Request Not Completed";
            }




        }
        public void UpdateTokens(string tid, int newTokens)
        {
            using (var con = new SqlConnection(Operations.QueryString))
            {
                using (var cmd = new SqlCommand("update tblTokens set tcount = @tcount where t_id = @tid", con))
                {
                    cmd.Parameters.AddWithValue("@tcount", newTokens);
                    cmd.Parameters.AddWithValue("@tid", tid);
                    con.Open();

                    cmd.ExecuteNonQuery();

                    con.Close();
                }
            }
        }

        //  public string GetTokens(string Username, string TableNumber, string NoofTokens, string deviceID)
        //  {
        //      throw new NotImplementedException();
        // }


        public List<Restaurant> GetRestaurants()
        {
            return Restaurant.GetAll();
        }

        public List<DedicationsObject> CurrentDedications(string rid)
        {
            return Operations.GetCurrentDedications(rid);
        }

        public SongObject NowPlaying(string rid)
        {

            return Operations.NowPlaying(rid);
        }
    }
}
