﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WcfServiceTest
{
 [DataContract]
    public class AlbumObject
    {
        String a_id
        , name
        , artist
        , year;

     [DataMember]
        public String Year
        {
            get { return year; }
            set { year = value; }
        }
     [DataMember]
        public String Artist
        {
            get { return artist; }
            set { artist = value; }
        }
     [DataMember]
        public String Name
        {
            get { return name; }
            set { name = value; }
        }
     [DataMember]
        public String A_id
        {
            get { return a_id; }
            set { a_id = value; }
        }
    }
}