﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WcfServiceTest
{
    [DataContract]
    public class DedicationsObject
    {
        String d_id
         , dedicatedBy
         , dedicatedto
         , dedicationType
         , q_id
         , dedicationmessage
         , deviceId;

        [DataMember]
        public String DeviceId
        {
            get { return deviceId; }
            set { deviceId = value; }
        }
        [DataMember]
        public String Dedicationmessage
        {
            get { return dedicationmessage; }
            set { dedicationmessage = value; }
        }
        [DataMember]
        public String Q_id
        {
            get { return q_id; }
            set { q_id = value; }
        }
        [DataMember]
        public String DedicationType
        {
            get { return dedicationType; }
            set { dedicationType = value; }
        }
        [DataMember]
        public String Dedicatedto
        {
            get { return dedicatedto; }
            set { dedicatedto = value; }
        }
        [DataMember]
        public String DedicatedBy
        {
            get { return dedicatedBy; }
            set { dedicatedBy = value; }
        }
        [DataMember]
        public String D_id
        {
            get { return d_id; }
            set { d_id = value; }
        }
    }
}