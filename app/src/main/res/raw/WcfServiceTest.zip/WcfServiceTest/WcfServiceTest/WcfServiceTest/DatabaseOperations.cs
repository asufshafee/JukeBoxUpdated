﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WcfServiceTest
{
    public class DatabaseOperation
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter sda;
        public DatabaseOperation()
        {

            con = new SqlConnection(Operations.QueryString);
            con.Open();
        }

        public DataTable getDataFromDB(String Query)
        {
            cmd = new SqlCommand(Query, con);

            cmd.ExecuteNonQuery();
            sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            return dt;
        }

        public bool InsertDataQuery(String Query)
        {


            cmd = new SqlCommand(Query, con);

            if (cmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            //con.Close();

            //sda = new SqlDataAdapter(cmd);
        }
    }
}