﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfServiceTest
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {



        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Wrapped,
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "GetLibrary/{Album}/{rid}")]
        List<SongObject> GetLibrary(string Album, string rid);

        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Wrapped,
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "GetAllPoopularSongs/{rid}")]
        List<SongObject> GetAllPoopularSongs(string rid);
        

        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Wrapped,
           RequestFormat = WebMessageFormat.Json,
           ResponseFormat = WebMessageFormat.Json,
           UriTemplate = "GetQueue/{rid}")]
        List<SongObject> GetQueue(string rid);



        //Table Dedication to  insert
        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Wrapped,
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "insertDedications/{dedicatedBy}/{dedicatedTo}/{dedicationType}/{q_id}/{dedicationmessage}/{deviceId}/{NoOfTokens}/{rid}/{tokenType}")]
        String insertDedications(String dedicatedBy, String dedicatedTo, String dedicationType, String q_id, String dedicationmessage, String deviceId, string NoOfTokens, string rid, string tokenType);

        //Table Dedication to  insert
        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Wrapped,
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "GetTokens/{Username}/{TableNumber}/{NoofTokens}/{deviceID}/{rid}/{tokenType}")]
        String GetTokens(String Username, String TableNumber, String NoofTokens, String deviceID, string rid, string tokenType);
        
      
        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Wrapped,
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "GetRequests/{deviceID}")]
        List<TokenObject> GetRequests(String deviceID);


        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Wrapped,
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "RequestSong/{deviceID}/{NoOFTokens}/{song_id}/{rid}/{tokenType}")]
        string RequestSong(String deviceID,string NoOFTokens, string song_id, string rid, string tokenType); // 1 = Silver, 2 = GOld, 3 = Platinum


        //to get todat theme to show in theme activity
        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Wrapped,
           RequestFormat = WebMessageFormat.Json,
           ResponseFormat = WebMessageFormat.Json,
           UriTemplate = "selecTheme/{rid}")]
        List<ThemeObject> selecTheme(string rid);
        

        //to get todat theme to show in theme activity
        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Wrapped,
           RequestFormat = WebMessageFormat.Json,
           ResponseFormat = WebMessageFormat.Json,
           UriTemplate = "GetRestaurants")]
        List<Restaurant> GetRestaurants();

        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Wrapped,
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "CurrentDedications/{rid}")]
        List<DedicationsObject> CurrentDedications(string rid);

        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Wrapped,
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "NowPlaying/{rid}")]
        SongObject NowPlaying(string rid);


    }
}
