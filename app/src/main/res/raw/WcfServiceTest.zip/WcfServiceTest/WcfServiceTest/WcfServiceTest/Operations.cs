﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using System.Web;

namespace WcfServiceTest
{
    public class Operations
    {

        public static String QueryString = @"Data Source=DESKTOP-QM3MSBC;Initial Catalog=Rockjukebox;Persist Security Info=True;User ID=sa;Password=123 ;Trusted_Connection=false;Connection Timeout=300;";


        public static int GetId(String TableName)
        {
            SqlConnection con = new SqlConnection(QueryString);
            con.Open();
            String query = "select * from " + TableName;
            SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);

            int id = dt.Rows.Count;
            return id + 2;


        }
        public static List<String> GetAlbams()
        {
            List<String> List = new List<string>();
            SqlConnection con = new SqlConnection(QueryString);
            con.Open();
            String query = "select * from tblAlbum";
            SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);

            foreach (DataRow row in dt.Rows)
            {
                List.Add(row["name"].ToString());
            }

            return List;



        }
        public static List<String> GetTheams()
        {
            List<String> List = new List<string>();
            SqlConnection con = new SqlConnection(QueryString);
            con.Open();
            String query = "select * from tblTheme";
            SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);

            foreach (DataRow row in dt.Rows)
            {
                List.Add(row["name"].ToString());
            }

            return List;



        }


        public static List<DedicationsObject> GetCurrentDedications(string rid)
        {
            var dedicationObject = new List<DedicationsObject>();
            try
            {

                using (var con = new SqlConnection(Operations.QueryString))
                {
                    using (var cmd = new SqlCommand("select * from tblNowPlaying n join tblDedications d on n.q_id = d.q_id where d.rid = @rid", con))
                    {
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        cmd.Parameters.AddWithValue("@rid", rid);
                        var sdr = cmd.ExecuteReader();

                        while (sdr.Read())
                        {
                            dedicationObject.Add(new DedicationsObject
                            {
                                D_id = sdr["d_id"].ToString(),
                                DedicatedBy = sdr["dedicatedBy"].ToString(),
                                Dedicatedto = sdr["dadicatedto"].ToString(),
                                DedicationType = sdr["DedicationType"].ToString(),
                                Dedicationmessage = sdr["Dedicationmessage"].ToString(),
                                DeviceId = sdr["deviceid"].ToString(),
                                Q_id = sdr["q_id"].ToString()
                            });
                        }

                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                dedicationObject.Add(new DedicationsObject { Dedicationmessage = ex.Message });
            }
            return dedicationObject;
        }

        public static SongObject NowPlaying(string rid)
        {
            var song = new SongObject();
            using (var con = new SqlConnection(Operations.QueryString))
            {
                using (var cmd = new SqlCommand("select * from tblNowPlaying n join tblSongs s on n.s_id = s.s_id  where s.rid = @rid", con))
                {
                    if (con.State != ConnectionState.Open)
                        con.Open();
                    cmd.Parameters.AddWithValue("@rid", rid);
                    var sdr = cmd.ExecuteReader();

                    while (sdr.Read())
                    {
                        song.S_id = sdr["s_id"].ToString();
                        //song.A_id = sdr["a_id"].ToString();
                        song.AlbumName = sdr["a_id"].ToString();
                        song.Duration = sdr["duration"].ToString();
                        song.Title = sdr["title"].ToString();
                        song.Path = sdr["path"].ToString();
                        song.Playstatus = sdr["playstatus"].ToString();
                    }

                    con.Close();
                }
            }

            return song;
        }
    }

}