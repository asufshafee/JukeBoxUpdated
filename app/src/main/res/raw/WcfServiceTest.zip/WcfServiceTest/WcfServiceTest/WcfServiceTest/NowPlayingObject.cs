﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WcfServiceTest
{ [DataContract]
    public class NowPlayingObject
    {
        string q_id, s_id, priority;

        public string Priority
        {
            get { return priority; }
            set { priority = value; }
        }

        public string S_id
        {
            get { return s_id; }
            set { s_id = value; }
        }

        public string Q_id
        {
            get { return q_id; }
            set { q_id = value; }
        }



    }
}