﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WcfServiceTest
{
    [DataContarct]
    public class TokenHistory

    {
        [DataMember]
        public string ConsumedTokens { get; set; }

        public static List<TokenHistory> GetHistory(string tokenId)
        {
            List<TokenHistory> history = new List<TokenHistory>();
            using (var con = new SqlConnection(Operations.QueryString))
            {
                using (var cmd = new SqlCommand("select * from tblTokenHistory where t_id = @id", con))
                {
                    cmd.Parameters.AddWithValue("@id", tokenId);

                    
                    con.Open();

                    var sdr = cmd.ExecuteReader();

                    while (sdr.Read())
                    {
                        history.Add(new TokenHistory { ConsumedTokens = sdr["consumedTokens"].ToString() });
                    }
                    

                    con.Close();
                }
            }
            return history;
        }
    }
}