﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WcfServiceTest
{
    [DataContarct]
    public class QueueObject
    {
        string q_id
      , s_id
      , priority;
        [DataMember]
        public string Priority
        {
            get { return priority; }
            set { priority = value; }
        }
           [DataMember]
        public string S_id
        {
            get { return s_id; }
            set { s_id = value; }
        }
           [DataMember]
        public string Q_id
        {
            get { return q_id; }
            set { q_id = value; }
        }





    }
}