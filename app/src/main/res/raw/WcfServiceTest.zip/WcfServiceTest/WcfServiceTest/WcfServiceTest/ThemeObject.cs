﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WcfServiceTest
{

   [DataContract]
    public class ThemeObject
    {
        string theme_id
      , name
      , status;

       [DataMember]
        public string Status
        {
            get { return status; }
            set { status = value; }
        }
       [DataMember]
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
       [DataMember]
        public string Theme_id
        {
            get { return theme_id; }
            set { theme_id = value; }
        }
      

   

    }
}